package com.kcom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;

public class VendingMachine {
	
	// this method is for choose between unlimited coin or limited coin.
	public Boolean init() throws IOException{
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Select: ");
        System.out.println("Unlimited Coin: (1) OR Limited Coin (2) ");
        String isOptimal = in.readLine();
        System.out.println("You Selected: " + isOptimal);
       
        if(isOptimal.equals("1")||isOptimal.equals("2")){
               return Boolean.valueOf(isOptimal.equals("1") ? true : false );
        }else{
        	System.out.println("Please select only one option.");
        	return init();
        }
       
  }
	// This method is for enter the value of the product.
	public int priceVal() throws IOException{
        try {
        	String cPrice;
        	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        	System.out.println("Product value: ");
        	String price = in.readLine();
        	System.out.println("The value of the product you entered is: �" + price);
        	cPrice = price.replaceAll("[-+.,]","");
        	
        	return Integer.valueOf(cPrice);
			
		} catch (NumberFormatException nb) {
			System.out.println("select only number format");
			return priceVal();
		} catch(Exception e){
			e.printStackTrace();
			return priceVal();
		}
       
  }
 
	public int moneyVal() throws IOException{
		try {
			String cMoney;
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	        System.out.println("Enter the value of you money in the machine: ");
	        String money = in.readLine();
	        System.out.println("the value you entered is: �" + money);
	        cMoney = money.replaceAll("[-+.,]","");
	        return Integer.valueOf(cMoney);
		
		} catch (NumberFormatException nb) {
			System.out.println("select only number format");
			return moneyVal();
		} catch(Exception e){
			e.printStackTrace();
			return moneyVal();
		}
  }
 
	public Collection<CoinVO> checkTypeChange(Boolean isOptimal, CoinVO c){
        if(isOptimal){
               return getOptimalChangeFor(c); // 1� Parte do projeto
        }else{
               return getChangeFor(c); // 2� Parte do projeto
        }
  }
 
	public Collection<CoinVO> getOptimalChangeFor(CoinVO c){
        System.out.println("Call getOptimalChangeFor!");
        Collection<CoinVO> d = new ArrayList<CoinVO>();
        /* Logica */
        System.out.println(c.getCoin());
        System.out.println(c.getValue());
        d.add(c);
       
        return d;
  }
 
	public Collection<CoinVO> getChangeFor(CoinVO c){
        System.out.println("Call getChangeFor!");
        Collection<CoinVO> d = new ArrayList<CoinVO>();
        /* Logica */
        d.add(c);
       
        return d;
  }
	
}
