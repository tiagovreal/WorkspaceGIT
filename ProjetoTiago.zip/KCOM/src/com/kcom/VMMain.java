package com.kcom;

import java.io.IOException;
import java.util.Collection;
import com.kcom.CoinVO;
import com.kcom.VendingMachine;
 
public class VMMain {
   public static void main(String[] args) throws IOException  {
	   VendingMachine vm = new VendingMachine();
	   Boolean isOptmal = vm.init();
	   CoinVO tr = new CoinVO();
	   tr.setCoin(vm.priceVal());
	   tr.setValue(vm.moneyVal());
        
	   Collection<CoinVO> c = vm.checkTypeChange(isOptmal, tr);
	   for (CoinVO coinVO : c) {
		   CoinVO d = coinVO;
		   System.out.println("PRECO :" +d.getCoin());
	   }
   }
}