package com.kcom;

import java.io.Serializable;

public class CoinVO implements Serializable, Cloneable {
	 
    private static final long serialVersionUID = 1L;
    int coin = 0;
    int value = 0;
    /* */
   
    public int getValue() {
           return value;
    }
    public void setValue(int value) {
           this.value = value;
    }
    public int getCoin() {
           return coin;
    }
    public void setCoin(int coin) {
           this.coin = coin;
    }
}