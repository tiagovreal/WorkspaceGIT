package com.kcom;

import java.io.IOException;
import java.util.Collection;
import com.kcom.CoinVO;
import com.kcom.VendingMachine;
 
public class VMMain {
	public static void main(String[] args) throws IOException{
		VendingMachine vm = new VendingMachine();
		CoinVO tr = new CoinVO();
		Boolean isOptmal = vm.init();
		System.out.println("Enter the value of the product: ");
		tr.setProductPrice(vm.getFormatMoney());
		while(vm.checkMoney(tr.getMoneyValue(), tr.getProductPrice())){
			System.out.println("Enter the value of your money: ");
			tr.setMoneyValue(vm.getFormatMoney() + tr.getMoneyValue());
		}
		tr.setChange(tr.getMoneyValue() - tr.getProductPrice());
		Collection<CoinVO> c;
		try{
			if (isOptmal){
				c = vm.getOptimalChangeFor(tr.getChange());
			}else{
				c = vm.getChangeFor(tr.getChange());
			}
			for (CoinVO coinVO : c) {
				System.out.println(coinVO.getDenomination() + "p = " + coinVO.getQty());
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}