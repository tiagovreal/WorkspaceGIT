package com.kcom;

public class CoinVO {
    private int productPrice = 0;
    private int moneyValue = 0;
    private int change = 0;
    private int denomination = 0;
	private int qty = 0; 

	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public int getMoneyValue() {
		return moneyValue;
	}
	public void setMoneyValue(int moneyValue) {
		this.moneyValue = moneyValue;
	}
	
	public int getDenomination() {
		return denomination;
	}
	public void setDenomination(int denomination) {
		this.denomination = denomination;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getChange() {
		return change;
	}
	public void setChange(int change) {
		this.change = change;
	}
	
	public CoinVO(int denomination){
		this.setDenomination(denomination);
	}
	public CoinVO(int denomination, int qty){
		this.setDenomination(denomination);
		this.setQty(qty);
	}
	public CoinVO() {
		
	}
}