package com.kcom;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;


public class VendingMachine {
	
	// this method is for choose between getOptimalChangeFor coin or getChangeFor coin.
	public Boolean init() throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter: (1) for 'getOptimalChangeFor' or (2) 'getChangeFor'");
        String isOptimal = in.readLine();
       
        if(isOptimal.equals("1") || isOptimal.equals("2")){
        	if(isOptimal.equals("1")){
        		System.out.println("You Selected: Unlimited Coin - Part One");
        	}else{
        		System.out.println("You Selected: Limited Coin - Part Two");
        	}
        	return Boolean.valueOf(isOptimal.equals("1") ? true : false );
        }else{
        	System.out.println("##Please select only one option: 1 or 2.##");
        	return init();
        }
       
	}
	//This method for format the value of the money
	public int getFormatMoney(){
		 try {
	        	String cPrice;
	        	int finalVal;
	        	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	        	String price = in.readLine();
	        	if(!price.contains("+") && !price.contains("-")){        		
	        		if(price.contains(",") || price.contains(".")){
	        			cPrice = price.replaceAll("[.,]","");
	        			finalVal = (int) ((Double.valueOf(cPrice) / 100) * 100);
	        			System.out.println("The value you entered is: �" + price);
	        			return finalVal;
	        		}else{
	        			cPrice = price.replaceAll("[.,]","");
	        			finalVal = Integer.valueOf(cPrice) * 100;
	        			System.out.println("The value you entered is: �" + price);
	        			return finalVal;
	        		}
	        	}else{
	        		System.out.println("##Select only number##");
	        		return getFormatMoney();
	        	}
			} catch (NumberFormatException nb) {
				System.out.println("##Select only number##");
				return getFormatMoney();
			} catch(Exception e){
				e.printStackTrace();
				return getFormatMoney();
			}
	}
	//method for checking the if the money is enough to value of the product
	public boolean checkMoney(int money, int prod){
		boolean check;
		int change = money - prod;
		if(prod != 0 && money != 0){
			if(change < 0){
				Double showChange = (double) change;
				showChange = showChange / 100;
				System.out.println("insufficient money, put more: �" + showChange.toString().replace(".", ",").replace("-", "") + " to complete the value");
				check = true;
			}else{
				check = false;
			}
			
		}else{
			check = true;
		}
		return check;
	}
	
	//Part One
	public Collection<CoinVO> getOptimalChangeFor(int pence){
		Collection<CoinVO> change = new ArrayList<CoinVO>(coins.length);
		try {
			Double showChange = (double) pence;
			showChange = showChange / 100;
			System.out.println("Your change is: �" + showChange.toString().replace(".", ","));
			
			for (int i=0;i<coins.length;i++){
				int quantity = pence / coins[i][0];
				CoinVO coin = new CoinVO(coins[i][0],quantity);
				change.add(coin);
				pence = pence % coins[i][0];
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return change;
	}
	
	//Part Two
	public Collection<CoinVO> getChangeFor(int pence) throws Exception{
		Collection<CoinVO> change = new ArrayList<CoinVO>(coins.length);
			Double showChange = (double) pence;
			showChange = showChange / 100;
	        System.out.println("Your change is: �" + showChange.toString().replace(".", ","));
			Properties coinRegister = loadCoinProperties();
			for (int i = 0; i < coins.length; i++){
				 int qty = 0;
				 qty = pence / coins[i][0];
				 int howManyCoins = coins[i][1] - qty;
				 if (howManyCoins < 0) {
					 qty = qty + howManyCoins; 
				 }
				 CoinVO coin = new CoinVO(coins[i][0],qty);
				 change.add(coin);
				 pence = pence-(coins[i][0] * qty);
				 coins[i][1] = coins[i][1] - qty;		 
			 }
			if (pence > 0) {
				throw new Exception ("No change avaliable. Contact support");
			}
			saveCoinProperties(coinRegister);
		return change;
	}
	
	//method for load the coinProperties
	private static Properties loadCoinProperties() throws IOException{
		Properties properties = new Properties();
		try {
			File file = new File(fileName);
			FileInputStream fileInput = new FileInputStream(file);
			properties.load(fileInput);
			fileInput.close();
			
			for (int i = 0; i < coins.length; i++){
				coins[i][1] = new Integer(properties.getProperty(coins[i][0]+""));
			}
			
		} catch (Exception e) {
			System.out.println("Error trying read file");
			System.exit(1);
		}
		return properties;

	}
	//method for save the changes on the coinProperties
	private static void saveCoinProperties (Properties properties) throws IOException {
		try {
			for (int i = 0; i < coins.length; i++) {
				properties.setProperty(coins[i][0] + "", coins[i][1] + "");
			}
			FileOutputStream fileOut = new FileOutputStream(fileName);
			properties.store(fileOut,
					"Coin Inventory Properties \nInitial values: 100=11, 50=24, 20=0, 10=99, 5=200, 2=11, 1=23");
			fileOut.close();
		} catch (Exception e) {
			System.out.println("Error trying save file");
			System.exit(1);
		}
	}
	
	private static final String fileName = "coin-inventory.properties";
	private static final int[][] coins = {{100,-1},{50,-1},{20,-1},{10,-1},{5,-1},{2,-1},{1,-1}};
}
