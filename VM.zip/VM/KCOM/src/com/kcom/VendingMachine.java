package com.kcom;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;


public class VendingMachine {
	
	// This method chooses between getOptimalChangeFor or getChangeFor.
	public Boolean init() throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Select: (1) for 'getOptimalChangeFor' or (2) for 'getChangeFor'");
        String isOptimal = in.readLine();
       
        if(isOptimal.equals("1") || isOptimal.equals("2")){
        	if(isOptimal.equals("1")){
        		System.out.println("Chosen option: getOptimalChangeFor");
        	}else{
        		System.out.println("Chosen option: getChangeFor");
        	}
        	return Boolean.valueOf(isOptimal.equals("1") ? true : false );
        }else{
        	System.out.println("##Please select only one option: 1 or 2.##");
        	return init();
        }
       
	}
	//This method formats the value of the money
	public int getFormatMoney(){
		 try {
			 	DecimalFormat twoPlaces = new DecimalFormat("0.00");
	        	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	        	String val = in.readLine();
	        	val = val.replaceAll("[,]",".");
	        	if(Double.valueOf(val) > -1 && Double.valueOf(val) <= 1000){
	        		if(!val.contains("+") && !val.contains("-")){        		
        				if(BigDecimal.valueOf(Double.valueOf(val)).scale() <= 2){
        					val = twoPlaces.format(Double.valueOf(val));
        					System.out.println("The value you entered: �" + val);
        					return Integer.valueOf(val.replaceAll("[.,]",""));
        					
        				}else{
        					System.out.println("##Only numbers with a maximum of two decimals are accepted, e.g. 1.99 ##");
        					System.out.println("Insert other value: ");
        					return getFormatMoney();
        				}
	        		}else{
	        			System.out.println("##Only numbers are accepted##");
	        			System.out.println("Insert other value: ");
	        			return getFormatMoney();
	        		}
	        	}else{
	        		System.out.println("##Only numbers between 0.01 and 1000 are accepted##");
        			System.out.println("Insert other value: ");
        			return getFormatMoney();
	        	}
			} catch (NumberFormatException nb) {
				System.out.println("##Only numbers are accepted##");
				System.out.println("Insert other value: ");
				return getFormatMoney();
			} catch(Exception e){
				System.out.println("Error: " + e);
				return getFormatMoney();
			}
	}
	//This method checks if the money is enough to pay the full amount of the product
	public boolean checkMoney(int money, int prod){
		boolean check;
		int change = money - prod;
		if(prod != 0 && money != 0){
			if(change < 0){
				Double showChange = (double) change;
				showChange = showChange / 100;
				System.out.println("Insufficient money, please insert more �" + showChange.toString().replace(".", ",").replace("-", "") + " to pay for the product");
				check = true;
			}else{
				check = false;
			}
			
		}else{
			check = true;
		}
		return check;
	}
	
	//Part One
	public Collection<CoinVO> getOptimalChangeFor(int pence){
		Collection<CoinVO> change = new ArrayList<CoinVO>(coins.length);
		try {
			Double showChange = (double) pence;
			showChange = showChange / 100;
			System.out.println("Your change: �" + showChange.toString().replace(".", ","));
			
			for (int i=0;i<coins.length;i++){
				int quantity = pence / coins[i][0];
				CoinVO coin = new CoinVO(coins[i][0],quantity);
				change.add(coin);
				pence = pence % coins[i][0];
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return change;
	}
	
	//Part Two
	public Collection<CoinVO> getChangeFor(int pence) throws Exception{
		Collection<CoinVO> change = new ArrayList<CoinVO>(coins.length);
			Double showChange = (double) pence;
			showChange = showChange / 100;
	        System.out.println("Your change: �" + showChange.toString().replace(".", ","));
			Properties coinRegister = loadCoinProperties();
			for (int i = 0; i < coins.length; i++){
				 int qty = 0;
				 qty = pence / coins[i][0];
				 int howManyCoins = coins[i][1] - qty;
				 if (howManyCoins < 0) {
					 qty = qty + howManyCoins; 
				 }
				 CoinVO coin = new CoinVO(coins[i][0],qty);
				 change.add(coin);
				 pence = pence-(coins[i][0] * qty);
				 coins[i][1] = coins[i][1] - qty;		 
			 }
			if (pence > 0) {
				throw new Exception ("No change available. Please contact support.");
			}
			saveCoinProperties(coinRegister);
		return change;
	}
	
	//This method loads the coinProperties
	private static Properties loadCoinProperties() throws IOException{
		Properties properties = new Properties();
		try {
			File file = new File(fileName);
			FileInputStream fileInput = new FileInputStream(file);
			properties.load(fileInput);
			fileInput.close();
			
			for (int i = 0; i < coins.length; i++){
				coins[i][1] = new Integer(properties.getProperty(coins[i][0]+""));
			}
			
		} catch (Exception e) {
			System.out.println("Error: could not read file");
			System.exit(1);
		}
		return properties;

	}
	//This method saves the changes on the coinProperties
	private static void saveCoinProperties (Properties properties) throws IOException {
		try {
			for (int i = 0; i < coins.length; i++) {
				properties.setProperty(coins[i][0] + "", coins[i][1] + "");
			}
			FileOutputStream fileOut = new FileOutputStream(fileName);
			properties.store(fileOut,
					"Coin Inventory Properties \nInitial values: 100=11, 50=24, 20=0, 10=99, 5=200, 2=11, 1=23");
			fileOut.close();
		} catch (Exception e) {
			System.out.println("Error: could not save file");
			System.exit(1);
		}
	}
	
	private static final String fileName = "coin-inventory.properties";
	private static final int[][] coins = {{100,-1},{50,-1},{20,-1},{10,-1},{5,-1},{2,-1},{1,-1}};
}
