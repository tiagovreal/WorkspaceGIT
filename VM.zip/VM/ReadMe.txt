To execute the project:

1 - Open Command Prompt and navigate to folder "VM"(contain: VendingMachine.jar, coin-inventory.properties, folder with the project "KCOM" and ReadMe)
2 - execute the jar(enter in the prompt "java -jar VendingMachine.jar")

Java version 8.